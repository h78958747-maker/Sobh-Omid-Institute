import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost';
  isLoading?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  isLoading = false, 
  className = '',
  disabled,
  ...props 
}) => {
  // Base: Glassmorphism + Physics
  const baseStyles = "relative overflow-hidden px-8 py-3.5 rounded-xl font-bold tracking-wide transition-all duration-300 transform active:scale-[0.96] hover:-translate-y-1 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none disabled:shadow-none group backdrop-blur-sm";
  
  const variants = {
    primary: "bg-white text-black shadow-[0_0_20px_rgba(255,255,255,0.2)] hover:shadow-[0_0_35px_rgba(255,255,255,0.4)] border border-white/50",
    secondary: "bg-white/5 hover:bg-white/10 text-white border border-white/10 hover:border-white/30 shadow-glass",
    danger: "bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 shadow-[0_0_20px_rgba(239,68,68,0.1)]",
    ghost: "bg-transparent hover:bg-white/5 text-gray-400 hover:text-white border border-transparent",
  };

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${className}`}
      disabled={disabled || isLoading}
      {...props}
    >
      {/* Dynamic Shimmer for Primary */}
      {variant === 'primary' && !disabled && !isLoading && (
        <div className="absolute inset-0 -translate-x-full group-hover:animate-shimmer bg-shimmer-gradient z-0 opacity-40"></div>
      )}
      
      {/* Background glow for Secondary */}
      {variant === 'secondary' && (
        <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-md"></div>
      )}

      {/* Content */}
      <span className="relative z-10 flex items-center gap-2">
        {isLoading ? (
          <>
            <div className="relative w-5 h-5">
              <div className="absolute inset-0 border-2 border-current opacity-20 rounded-full"></div>
              <div className="absolute inset-0 border-2 border-t-transparent border-current rounded-full animate-spin"></div>
            </div>
            <span className="animate-pulse tracking-widest text-xs uppercase">Processing</span>
          </>
        ) : children}
      </span>
    </button>
  );
};